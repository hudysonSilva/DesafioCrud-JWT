//package br.com.crud.desafiocrud.entity;
//
//
//
//import javax.persistence.*;
//import java.util.Objects;
//
//@Entity
//@NamedQueries(value = {
//        @NamedQuery(name = "ParametroSistema.findByCodigo", query = "SELECT c FROM ParametroSistema c WHERE c.codigo = :codigo"),
//        @NamedQuery(name = "ParametroSistema.findAll", query =
//        "SELECT c FROM ParametroSistema c")})
//
//@Table(name = "parametro_sistema")
//public class ParametroSistema {
//
//    public static final String FIND_BY_CODIGO = "ParametroSistema.findByCodigo";
//    public static final String FIND_ALL = "ParametroSistema.findAll";
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Integer id;
//
//    @Column(length = 255, nullable = false)
//    private String codigo;
//
//    @Column(length = 255)
//    private String descricao;
//
//    @Column(length = 255, nullable = false)
//    private String descricaoCampo1;
//
//    @Column(length = 255, nullable = false)
//    private String valorCampo1;
//
//    @Column(length = 255)
//    private String descricaoCampo2;
//
//    @Column(length = 255)
//    private String valorCampo2;
//
//    @Column(length = 255)
//    private String descricaoCampo3;
//
//    @Column(length = 255)
//    private String valorCampo3;
//
//    @Override
//    public boolean equals(Object o) {
//        if (this == o) return true;
//        if (o == null || getClass() != o.getClass()) return false;
//        ParametroSistema that = (ParametroSistema) o;
//        return Objects.equals(id, that.id);
//    }
//
//    @Override
//    public int hashCode() {
//        return Objects.hash(id);
//    }
//
//    public Integer getId() {
//        return id;
//    }
//
//    public void setId(Integer id) {
//        this.id = id;
//    }
//
//    public String getCodigo() {
//        return codigo;
//    }
//
//    public void setCodigo(String codigo) {
//        this.codigo = codigo.toUpperCase().trim();
//    }
//
//    public String getDescricao() {
//        return descricao;
//    }
//
//    public void setDescricao(String descricao) {
//        this.descricao = descricao;
//    }
//
//    public String getDescricaoCampo1() {
//        return descricaoCampo1;
//    }
//
//    public void setDescricaoCampo1(String descricaoCampo1) {
//        this.descricaoCampo1 = descricaoCampo1;
//    }
//
//    public String getValorCampo1() {
//        return valorCampo1;
//    }
//
//    public void setValorCampo1(String valorCampo1) {
//        this.valorCampo1 = valorCampo1;
//    }
//
//    public String getDescricaoCampo2() {
//        return descricaoCampo2;
//    }
//
//    public void setDescricaoCampo2(String descricaoCampo2) {
//        this.descricaoCampo2 = descricaoCampo2;
//    }
//
//    public String getValorCampo2() {
//        return valorCampo2;
//    }
//
//    public void setValorCampo2(String valorCampo2) {
//        this.valorCampo2 = valorCampo2;
//    }
//
//    public String getDescricaoCampo3() {
//        return descricaoCampo3;
//    }
//
//    public void setDescricaoCampo3(String descricaoCampo3) {
//        this.descricaoCampo3 = descricaoCampo3;
//    }
//
//    public String getValorCampo3() {
//        return valorCampo3;
//    }
//
//    public void setValorCampo3(String valorCampo3) {
//        this.valorCampo3 = valorCampo3;
//    }
//}
