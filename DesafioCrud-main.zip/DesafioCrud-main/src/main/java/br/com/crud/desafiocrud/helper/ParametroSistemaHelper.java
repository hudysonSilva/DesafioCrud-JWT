//package br.com.crud.desafiocrud.helper;
//
//import br.com.crud.desafiocrud.repositories.ClienteRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
//@Component(value = "parametroSistemaHelper")
//public class ParametroSistemaHelper {
//
//    @Autowired
//    private ClienteRepository cr;
//}
